package service

import (
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"trenerbot/internal/auth"
	"trenerbot/internal/domain"
	"trenerbot/internal/store"
)

type Services struct {
	Store  *store.Store
	Tokens *auth.TokenService
}

func New(store *store.Store, tokens *auth.TokenService) *Services {
	return &Services{Store: store, Tokens: tokens}
}

// ---------- Auth / registration ----------

type TelegramLoginRequest struct {
	TelegramID    string `json:"telegram_id"`
	FullName      string `json:"full_name"`
	Phone         string `json:"phone"`
	Age           int    `json:"age"`
	MedicalLimits string `json:"medical_limits"`
	Source        string `json:"source"`
}

// TelegramLogin resolves (or creates) a student account linked to a Telegram ID and returns a JWT.
func (s *Services) TelegramLogin(req TelegramLoginRequest) (*domain.User, *domain.Student, string, error) {
	u, err := s.Store.UserByTelegram(req.TelegramID)
	if err != nil {
		return nil, nil, "", err
	}
	if u == nil {
		uid, err := s.Store.CreateUser(&req.TelegramID, domain.RoleClient)
		if err != nil {
			return nil, nil, "", err
		}
		src := req.Source
		st := domain.Student{
			UserID:        &uid,
			FullName:      req.FullName,
			Phone:         nullable(req.Phone),
			Age:           nullableInt(req.Age),
			MedicalLimits: nullable(req.MedicalLimits),
			Status:        "active",
			Source:        nullable(src),
		}
		sid, err := s.Store.CreateStudentFull(st)
		if err != nil {
			return nil, nil, "", err
		}
		u = &domain.User{ID: uid, TelegramID: &req.TelegramID, Role: domain.RoleClient}
		student, _ := s.Store.StudentByID(sid)
		tok, err := s.Tokens.Generate(uid, u.Role)
		if err != nil {
			return nil, nil, "", err
		}
		_ = s.notifyCoaches("new_client", map[string]any{"user_id": uid, "name": req.FullName})
		return u, student, tok, nil
	}

	// existing user: refresh student profile if provided
	if u.Role == domain.RoleClient {
		st, err := s.Store.StudentByUserID(u.ID)
		if err != nil {
			return nil, nil, "", err
		}
		if st != nil && req.FullName != "" {
			st.FullName = req.FullName
			if req.Phone != "" {
				v := req.Phone
				st.Phone = &v
			}
			if req.Age > 0 {
				v := req.Age
				st.Age = &v
			}
			if req.MedicalLimits != "" {
				v := req.MedicalLimits
				st.MedicalLimits = &v
			}
			_ = s.Store.UpdateStudent(*st)
		}
	}
	tok, err := s.Tokens.Generate(u.ID, u.Role)
	if err != nil {
		return nil, nil, "", err
	}
	student, _ := s.Store.StudentByUserID(u.ID)
	return u, student, tok, nil
}

func (s *Services) notifyCoaches(typ string, payload map[string]any) error {
	coaches, err := s.Store.ListCoaches()
	if err != nil {
		return err
	}
	b, _ := json.Marshal(payload)
	for _, co := range coaches {
		if co.UserID == nil {
			continue
		}
		_ = s.enqueue(*co.UserID, typ, string(b), time.Now())
	}
	return nil
}

func (s *Services) enqueue(userID int64, typ, payload string, sendAt time.Time) error {
	_, err := s.Store.InsertNotification(domain.Notification{
		Channel:         "telegram",
		RecipientUserID: userID,
		Type:            typ,
		Payload:         payload,
		SendAt:          sendAt,
	})
	return err
}

// SetTelegramID links a Telegram ID to an existing user (used by admin to enable coach/admin bot access).
func (s *Services) SetTelegramID(userID int64, telegramID string) error {
	_, err := s.Store.DB.Exec(`UPDATE users SET telegram_id = ? WHERE id = ?`, telegramID, userID)
	return err
}

// ---------- Clients ----------

func (s *Services) GetStudent(id int64) (*domain.Student, error) { return s.Store.StudentByID(id) }

func (s *Services) ListStudents() ([]domain.Student, error) { return s.Store.ListStudents() }

func (s *Services) UpdateStudent(st domain.Student) error { return s.Store.UpdateStudent(st) }

func (s *Services) ChildrenOfParent(parentUserID int64) ([]domain.Student, error) {
	return s.Store.ChildrenOfParent(parentUserID)
}

// ---------- Coaches ----------

func (s *Services) CreateCoach(co domain.Coach) (int64, error) { return s.Store.CreateCoach(co) }

func (s *Services) ListCoaches() ([]domain.Coach, error) { return s.Store.ListCoaches() }

func (s *Services) CoachByUser(userID int64) (*domain.Coach, error) {
	return s.Store.CoachByUserID(userID)
}

// ---------- Lessons ----------

func (s *Services) CreateLesson(l domain.Lesson) (int64, error) {
	if l.Status == "" {
		l.Status = domain.LessonPlanned
	}
	return s.Store.CreateLesson(l)
}

func (s *Services) GetLesson(id int64) (*domain.Lesson, error) { return s.Store.LessonByID(id) }

func (s *Services) ListWeekLessons(coachID int64, from, to string) ([]domain.Lesson, error) {
	return s.Store.ListLessons(from, to, coachID)
}

func (s *Services) SetLessonStatus(id int64, status domain.LessonStatus) error {
	return s.Store.UpdateLessonStatus(id, status)
}

// ClientSchedule returns lessons the client is registered for (via attendance rows).
func (s *Services) ClientSchedule(clientID int64, from string) ([]domain.Lesson, error) {
	rows, err := s.Store.DB.Query(`SELECT l.id, l.date, l.time, l.coach_id, l.duration, l.status, l.location, l.comment, l.group_id
		FROM lessons l JOIN attendance a ON a.lesson_id = l.id WHERE a.client_id = ? AND l.date >= ? ORDER BY l.date, l.time`, clientID, from)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanLessons(rows)
}

// ---------- Attendance ----------

func (s *Services) MarkAttendance(lessonID, clientID int64, present bool, markedBy *int64) error {
	if err := s.Store.SetAttendance(lessonID, clientID, present, markedBy); err != nil {
		return err
	}
	typ := "visit"
	if !present {
		typ = "absence"
	}
	return s.Store.LogActivity(clientID, typ, lessonID, "", markedBy)
}

func (s *Services) ListAttendance(lessonID int64) ([]domain.Attendance, error) {
	return s.Store.ListAttendanceByLesson(lessonID)
}

// RegisterClientToLesson adds a client to a lesson (запись).
func (s *Services) RegisterClientToLesson(lessonID, clientID int64) error {
	return s.Store.SetAttendance(lessonID, clientID, false, nil)
}

// ---------- Lesson entries (new schedule model) ----------

func (s *Services) GetSchedule(from, to string, role domain.Role, userID, coachID, clientID int64) ([]domain.ScheduleEntry, error) {
	switch role {
	case domain.RoleCoach:
		return s.Store.ListScheduleEntries(from, to, coachID, 0)
	case domain.RoleClient:
		return s.Store.ListScheduleEntries(from, to, 0, clientID)
	default:
		return s.Store.ListScheduleEntries(from, to, 0, 0)
	}
}

// ---------- Lesson change notifications ----------

// NotifyLessonChange notifies all registered participants about a lesson change.
func (s *Services) NotifyLessonChange(lessonID int64, changeType string, oldVal, newVal string) error {
	parts, err := s.Store.LessonParticipants(lessonID)
	if err != nil {
		return err
	}
	lesson, err := s.Store.LessonByID(lessonID)
	if err != nil || lesson == nil {
		return err
	}
	for _, cid := range parts {
		st, err := s.Store.StudentByID(cid)
		if err != nil || st == nil || st.UserID == nil {
			continue
		}
		payload := map[string]any{
			"lesson_id":   lessonID,
			"date":        lesson.Date,
			"time":        lesson.Time,
			"location":    lesson.Location,
			"change_type": changeType,
			"old_value":   oldVal,
			"new_value":   newVal,
		}
		b, _ := json.Marshal(payload)
		_ = s.enqueue(*st.UserID, "lesson_change", string(b), time.Now())
	}
	return nil
}

// NotifyLessonCanceled notifies participants when a lesson is canceled.
func (s *Services) NotifyLessonCanceled(lessonID int64, reason string) error {
	parts, err := s.Store.LessonParticipants(lessonID)
	if err != nil {
		return err
	}
	lesson, err := s.Store.LessonByID(lessonID)
	if err != nil || lesson == nil {
		return err
	}
	for _, cid := range parts {
		st, err := s.Store.StudentByID(cid)
		if err != nil || st == nil || st.UserID == nil {
			continue
		}
		payload := map[string]any{
			"lesson_id": lessonID,
			"date":      lesson.Date,
			"time":      lesson.Time,
			"location":  lesson.Location,
			"reason":    reason,
		}
		b, _ := json.Marshal(payload)
		_ = s.enqueue(*st.UserID, "lesson_canceled", string(b), time.Now())
	}
	return nil
}

// ReapStaleClaimed returns 'claimed' rows that were never acknowledged within timeout back to 'pending'.
func (s *Services) ReapStaleClaimed(timeout time.Duration) (int64, error) {
	cutoff := time.Now().Add(-timeout).Format("2006-01-02 15:04:05")
	res, err := s.Store.DB.Exec(`UPDATE notifications SET status='pending', claim_token=NULL
		WHERE status='claimed' AND sent_at < ?`, cutoff)
	if err != nil {
		return 0, err
	}
	n, _ := res.RowsAffected()
	return n, nil
}

// EnsureReminders scans upcoming lessons and enqueues a day-of 08:00 reminder for each
// registered client (idempotent via NotificationExists). ТЗ §9.
func (s *Services) EnsureReminders() (int, error) {
	now := time.Now()
	from := now.Format("2006-01-02")
	to := now.AddDate(0, 0, 1).Format("2006-01-02")
	entries, err := s.Store.ListLessonEntriesForReminders(from, to)
	if err != nil {
		return 0, err
	}
	count := 0
	for _, e := range entries {
		if e.UserID == 0 {
			continue
		}
		sendAt, err := time.Parse("2006-01-02 15:04:05", e.Date+" 08:00:00")
		if err != nil || sendAt.Before(now) {
			continue
		}
		payload, _ := json.Marshal(map[string]any{
			"lesson_id": e.LessonID,
			"date":      e.Date,
			"time":      e.Time,
		})
		exists, err := s.Store.NotificationExists("lesson_reminder", e.UserID, string(payload))
		if err != nil || exists {
			continue
		}
		if err := s.enqueue(e.UserID, "lesson_reminder", string(payload), sendAt); err == nil {
			count++
		}
	}
	return count, nil
}

// ---------- Waiting List ----------

// AddToWaitingList adds a client to the waiting list.
func (s *Services) AddToWaitingList(clientID int64, groupID *int64) (int64, error) {
	// Get next position
	var pos int
	err := s.Store.DB.QueryRow(`SELECT COALESCE(MAX(position), 0) + 1 FROM waiting_list WHERE group_id IS ?`, groupID).Scan(&pos)
	if err != nil {
		pos = 1
	}
	res, err := s.Store.DB.Exec(`INSERT INTO waiting_list(client_id, group_id, position, created_at) VALUES (?, ?, ?, datetime('now'))`, clientID, groupID, pos)
	if err != nil {
		return 0, err
	}
	return res.LastInsertId()
}

// WaitingList is an alias for GetWaitingList for API compatibility.
func (s *Services) WaitingList(groupID *int64) ([]map[string]any, error) {
	return s.GetWaitingList(groupID)
}

// GetWaitingList returns the waiting list for a group (or all if groupID is nil).
func (s *Services) GetWaitingList(groupID *int64) ([]map[string]any, error) {
	q := `SELECT wl.id, wl.client_id, wl.group_id, wl.position, wl.created_at, c.full_name, c.phone
		FROM waiting_list wl JOIN clients c ON c.id = wl.client_id`
	args := []any{}
	if groupID != nil {
		q += ` WHERE wl.group_id = ?`
		args = append(args, *groupID)
	}
	q += ` ORDER BY wl.position`
	rows, err := s.Store.DB.Query(q, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var id, clientID int64
		var groupID sql.NullInt64
		var pos int
		var created, name, phone string
		if err := rows.Scan(&id, &clientID, &groupID, &pos, &created, &name, &phone); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{
			"id":         id,
			"client_id":  clientID,
			"group_id":   groupID,
			"position":   pos,
			"created_at": created,
			"name":       name,
			"phone":      phone,
		})
	}
	return out, rows.Err()
}

// RemoveFromWaitingList removes a client from the waiting list.
func (s *Services) RemoveFromWaitingList(id int64) error {
	_, err := s.Store.DB.Exec(`DELETE FROM waiting_list WHERE id = ?`, id)
	return err
}

// MoveFromWaitingList moves the first person from waiting list to a lesson.
func (s *Services) MoveFromWaitingList(lessonID int64) error {
	// Get first in waiting list
	var wlID, clientID int64
	err := s.Store.DB.QueryRow(`SELECT id, client_id FROM waiting_list WHERE group_id IS NULL ORDER BY position LIMIT 1`).Scan(&wlID, &clientID)
	if err != nil {
		return err // no one in waiting list
	}
	// Register to lesson
	if err := s.Store.SetAttendance(lessonID, clientID, false, nil); err != nil {
		return err
	}
	// Remove from waiting list
	_, _ = s.Store.DB.Exec(`DELETE FROM waiting_list WHERE id = ?`, wlID)
	// Reorder positions
	_, _ = s.Store.DB.Exec(`UPDATE waiting_list SET position = position - 1 WHERE position > (SELECT position FROM waiting_list WHERE id = ?)`, wlID)
	return nil
}

// ---------- Analytics / Debtors ----------

// DebtorsWidget returns clients with missed payments/attendance grouped by days.
func (s *Services) DebtorsWidget(days int) ([]map[string]any, error) {
	since := time.Now().AddDate(0, 0, -days).Format("2006-01-02")
	rows, err := s.Store.DB.Query(`
		SELECT c.id, c.full_name, c.phone, c.status,
		       COUNT(CASE WHEN a.present = 0 AND l.date >= ? THEN 1 END) as missed_count,
		       GROUP_CONCAT(l.date || ' ' || l.time) as missed_dates
		FROM clients c
		LEFT JOIN attendance a ON a.client_id = c.id
		LEFT JOIN lessons l ON l.id = a.lesson_id
		WHERE c.status = 'active' AND l.date >= ?
		GROUP BY c.id
		HAVING missed_count > 0
		ORDER BY missed_count DESC
	`, since, since)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var id int64
		var name, phone, status, missedDates string
		var missedCount int
		if err := rows.Scan(&id, &name, &phone, &status, &missedCount, &missedDates); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{
			"client_id":    id,
			"name":         name,
			"phone":        phone,
			"status":       status,
			"missed_count": missedCount,
			"missed_dates": missedDates,
		})
	}
	return out, rows.Err()
}

// ClientWellbeingFeedback records wellbeing feedback from client after training.
func (s *Services) ClientWellbeingFeedback(clientID int64, lessonID int64, wellbeing int, note string) error {
	_, err := s.Store.DB.Exec(`
		INSERT INTO activity_log(client_id, type, ref_id, note, created_by, created_at)
		VALUES (?, 'wellbeing', ?, ?, ?, datetime('now'))
	`, clientID, lessonID, note, clientID)
	return err
}

// GetStudentWellbeingHistory returns wellbeing history for a student.
func (s *Services) GetStudentWellbeingHistory(studentID int64) ([]map[string]any, error) {
	rows, err := s.Store.DB.Query(`
		SELECT al.id, al.ref_id, al.note, al.created_at, l.date, l.time
		FROM activity_log al
		LEFT JOIN lessons l ON l.id = al.ref_id
		WHERE al.client_id = ? AND al.type = 'wellbeing'
		ORDER BY al.created_at DESC
	`, studentID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var id, refID int64
		var note, created, date, time string
		if err := rows.Scan(&id, &refID, &note, &created, &date, &time); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{
			"id":         id,
			"lesson_id":  refID,
			"note":       note,
			"created_at": created,
			"date":       date,
			"time":       time,
		})
	}
	return out, rows.Err()
}

// NewClientFAQ returns FAQ variations for new clients based on their query.
func (s *Services) NewClientFAQ(query string) string {
	query = strings.ToLower(query)
	switch {
	case strings.Contains(query, "цена"):
		return "Цены"
	case strings.Contains(query, "расписание"):
		return "Расписание"
	case strings.Contains(query, "Медицина"):
		return "Медицинские ограничения"
	case strings.Contains(query, "Что взять"):
		return "Вещи"
	default:
		return "👋 Добро пожаловать! Частые вопросы:\n• /price — цены и абонементы\n• /schedule — расписание\n• /medical — мед. ограничения\n• /gear — что взять\n\nИли просто напишите свой вопрос — отвечу!"
	}
}

// ---------- Notification helpers (used by handlers) ----------

// Notify enqueues a notification for a specific user.
func (s *Services) Notify(userID int64, typ string, payload map[string]any, sendAt time.Time) error {
	b, _ := json.Marshal(payload)
	return s.enqueue(userID, typ, string(b), sendAt)
}

// MessageCoaches sends a message from a client to all coaches.
func (s *Services) MessageCoaches(fromName, text string) error {
	return s.notifyCoaches("client_message", map[string]any{"from": fromName, "text": text})
}

// ClaimDue claims due notifications for the bot to dispatch.
func (s *Services) ClaimDue(limit int) ([]domain.Notification, error) {
	token := randToken()
	return s.Store.ClaimDue(time.Now(), limit, token)
}

// MarkResult marks a notification as sent or failed.
func (s *Services) MarkResult(id int64, ok bool) error {
	if ok {
		return s.Store.MarkNotificationSent(id)
	}
	return s.Store.MarkNotificationFailed(id)
}

// SendResult is the result of a batch notification send.
type SendResult struct {
	Total    int `json:"total"`
	Enqueued int `json:"enqueued"`
	Skipped  int `json:"skipped"`
	Errors   int `json:"errors"`
}

// ListRecipients returns eligible recipients for a coach notification.
func (s *Services) ListRecipients(coachID int64, filter string, groupID int64, clientIDs []int64) ([]domain.Recipient, error) {
	switch filter {
	case "today":
		return s.Store.ListCoachRecipients(coachID, time.Now().Format("2006-01-02"), 0)
	case "tomorrow":
		return s.Store.ListCoachRecipients(coachID, time.Now().AddDate(0, 0, 1).Format("2006-01-02"), 0)
	case "group":
		return s.Store.ListCoachRecipients(coachID, "", groupID)
	case "manual":
		return s.Store.ListRecipientsByIDs(clientIDs)
	default:
		return s.Store.ListCoachRecipients(coachID, "", 0)
	}
}

// SendCoachNotification sends a notification to all selected recipients.
func (s *Services) SendCoachNotification(coachID int64, filter string, groupID int64, clientIDs []int64, title, text string) (*SendResult, error) {
	recipients, err := s.ListRecipients(coachID, filter, groupID, clientIDs)
	if err != nil {
		return nil, err
	}
	result := &SendResult{Total: len(recipients)}
	payload, _ := json.Marshal(map[string]string{
		"title": title,
		"text":  text,
	})
	for _, r := range recipients {
		if r.UserID == nil {
			result.Skipped++
			continue
		}
		if err := s.enqueue(*r.UserID, "coach_broadcast", string(payload), time.Now()); err != nil {
			result.Errors++
			continue
		}
		result.Enqueued++
	}
	return result, nil
}

// ---------- Daily attendance ----------

func (s *Services) GetDateAttendance(date string) ([]domain.DateAttendanceClient, error) {
	clients, err := s.Store.ListStudentsWithLessonsOnDate(date)
	if err != nil {
		return nil, err
	}
	existing, err := s.Store.GetDailyAttendance(date)
	if err != nil {
		return nil, err
	}
	for i := range clients {
		if p, ok := existing[clients[i].StudentID]; ok {
			v := p
			clients[i].Present = &v
		}
	}
	return clients, nil
}

func (s *Services) SaveDateAttendance(date string, entries []domain.DailyAttendance) error {
	return s.Store.SaveDailyAttendance(date, entries)
}

func (s *Services) GetSocialLinks(coachID int64) ([]domain.SocialLink, error) {
	if err := s.Store.SeedDefaultSocialLinks(coachID); err != nil {
		return nil, err
	}
	return s.Store.ListSocialLinks(coachID)
}

func (s *Services) GetSocialLinksMap(coachID int64) map[string]string {
	links, err := s.Store.ListSocialLinks(coachID)
	if err != nil {
		return map[string]string{}
	}
	m := make(map[string]string)
	for _, l := range links {
		if l.Enabled && l.URL != nil {
			m[l.Platform] = *l.URL
		}
	}
	return m
}

func (s *Services) SaveSocialLinks(coachID int64, links []domain.SocialLink) error {
	for _, l := range links {
		if err := s.Store.UpsertSocialLink(coachID, l.Platform, l.URL, l.Enabled); err != nil {
			return err
		}
	}
	return nil
}

// SocialMediaLinks returns configured social media links for the club/coach.
func (s *Services) SocialMediaLinks() map[string]string {
	return map[string]string{
		"instagram": "https://instagram.com/yourclub",
		"telegram":  "https://t.me/yourclub",
		"vk":        "https://vk.com/yourclub",
		"youtube":   "https://youtube.com/@yourclub",
	}
}

// ---------- Files ----------

func (s *Services) SaveFile(f domain.File) (int64, error) { return s.Store.InsertFile(f) }

// ---------- Reports ----------

type Report struct {
	ClientsTotal int `json:"clients_total"`
	CoachesTotal int `json:"coaches_total"`
	LessonsWeek  int `json:"lessons_week"`
}

func (s *Services) Report(from, to string) (*Report, error) {
	r := &Report{}
	students, err := s.Store.ListStudents()
	if err != nil {
		return nil, err
	}
	r.ClientsTotal = len(students)
	coaches, err := s.Store.ListCoaches()
	if err != nil {
		return nil, err
	}
	r.CoachesTotal = len(coaches)
	lessons, err := s.Store.ListLessons(from, to, 0)
	if err != nil {
		return nil, err
	}
	r.LessonsWeek = len(lessons)
	return r, nil
}

// ---------- helpers ----------

func scanLessons(rows *sql.Rows) ([]domain.Lesson, error) {
	var out []domain.Lesson
	for rows.Next() {
		l := &domain.Lesson{}
		var coachID, groupID sql.NullInt64
		var loc, comment sql.NullString
		if err := rows.Scan(&l.ID, &l.Date, &l.Time, &coachID, &l.Duration, &l.Status, &loc, &comment, &groupID); err != nil {
			return nil, err
		}
		if coachID.Valid {
			v := coachID.Int64
			l.CoachID = &v
		}
		if groupID.Valid {
			v := groupID.Int64
			l.GroupID = &v
		}
		if loc.Valid {
			v := loc.String
			l.Location = &v
		}
		if comment.Valid {
			v := comment.String
			l.Comment = &v
		}
		out = append(out, *l)
	}
	return out, rows.Err()
}

func nullable(s string) *string {
	if s == "" {
		return nil
	}
	return &s
}

func nullableInt(n int) *int {
	if n == 0 {
		return nil
	}
	return &n
}

var ErrNotFound = errors.New("not found")

func (s *Services) MustStudent(id int64) (*domain.Student, error) {
	c, err := s.Store.StudentByID(id)
	if err != nil {
		return nil, err
	}
	if c == nil {
		return nil, fmt.Errorf("%w: student %d", ErrNotFound, id)
	}
	return c, nil
}

func randToken() string {
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

// ---------- Coach Subscriptions ----------

const TrialDays = 7

func (s *Services) GetOrCreateCoachSubscription(coachID int64) (*domain.CoachSubscription, error) {
	sub, err := s.Store.CoachSubscriptionByCoachID(coachID)
	if err != nil {
		return nil, err
	}
	if sub == nil {
		return s.Store.CreateCoachSubscription(coachID, TrialDays)
	}
	return sub, nil
}

func (s *Services) GetCoachSubscription(coachID int64) (*domain.CoachSubscription, error) {
	return s.Store.CoachSubscriptionByCoachID(coachID)
}

func (s *Services) IsCoachSubscriptionActive(coachID int64) bool {
	sub, err := s.Store.CoachSubscriptionByCoachID(coachID)
	if err != nil || sub == nil {
		return false
	}
	if sub.Status == domain.SubActive {
		if sub.PaidUntil != nil {
			paidUntil, err := time.Parse("2006-01-02 15:04:05", *sub.PaidUntil)
			if err == nil && paidUntil.Before(time.Now()) {
				return false
			}
		}
		return true
	}
	if sub.Status == domain.SubTrial {
		if sub.TrialEnd != nil {
			trialEnd, err := time.Parse("2006-01-02 15:04:05", *sub.TrialEnd)
			if err == nil && trialEnd.Before(time.Now()) {
				_ = s.Store.UpdateCoachSubscriptionStatus(coachID, domain.SubExpired)
				return false
			}
		}
		return true
	}
	return false
}

// ---------- Parent features ----------

func (s *Services) FindChildByBirthDate(fullName, birthDate string) (*domain.Student, error) {
	return s.Store.StudentByBirthDate(fullName, birthDate)
}

func (s *Services) LinkParentToChild(parentUserID int64, studentID int64) error {
	return s.Store.LinkParentToChild(parentUserID, studentID)
}

func (s *Services) CreateInviteCode(studentID, createdBy int64) (string, error) {
	expiresAt := time.Now().Add(72 * time.Hour).Format("2006-01-02 15:04:05")
	return s.Store.CreateInviteCode(studentID, createdBy, expiresAt)
}

func (s *Services) UseInviteCode(code string) (int64, error) {
	return s.Store.UseInviteCode(code)
}

func (s *Services) GetParentNotifPrefs(parentUserID int64) ([]domain.ParentNotifPref, error) {
	return s.Store.GetParentNotifPrefs(parentUserID)
}

func (s *Services) SaveParentNotifPrefs(pref domain.ParentNotifPref) error {
	return s.Store.UpsertParentNotifPref(pref)
}

// GetChildLessonStatus returns lesson status info for a child for the parent dashboard.
func (s *Services) GetChildLessonStatus(childID int64) (*domain.ChildLessonStatus, error) {
	now := time.Now()
	today := now.Format("2006-01-02")
	currentTime := now.Format("15:04")

	entries, err := s.Store.ListChildLessonEntries(childID, today, today)
	if err != nil {
		return nil, err
	}

	student, err := s.Store.StudentByID(childID)
	if err != nil || student == nil {
		return nil, fmt.Errorf("%w: child %d", ErrNotFound, childID)
	}

	status := &domain.ChildLessonStatus{
		StudentID:      childID,
		FullName:       student.FullName,
		HasLessonToday: len(entries) > 0,
	}

	for _, e := range entries {
		if status.Date == "" || e.Date > status.Date || (e.Date == status.Date && e.Time > status.Time) {
			status.Date = e.Date
			status.Time = e.Time
			status.Duration = e.Duration
			status.Status = string(e.Status)
		}

		if e.Date == today {
			status.HasLessonToday = true
			startTime, err := time.Parse("15:04", e.Time)
			if err != nil {
				continue
			}
			currentParsed, err := time.Parse("15:04", currentTime)
			if err != nil {
				continue
			}
			startMinutes := startTime.Hour()*60 + startTime.Minute()
			currentMinutes := currentParsed.Hour()*60 + currentParsed.Minute()
			endMinutes := startMinutes + e.Duration

			if currentMinutes >= startMinutes && currentMinutes <= endMinutes {
				left := endMinutes - currentMinutes
				status.IsOngoing = true
				status.MinutesLeft = &left
			} else if currentMinutes < startMinutes {
				until := startMinutes - currentMinutes
				status.MinutesUntil = &until
			}
		}
	}

	status.IsToday = status.Date == today
	return status, nil
}

// ---------- Lesson status for parent dashboard ----------

func (s *Services) GetChildrenLessonStatuses(parentUserID int64) ([]domain.ChildLessonStatus, error) {
	children, err := s.ChildrenOfParent(parentUserID)
	if err != nil {
		return nil, err
	}
	var out []domain.ChildLessonStatus
	for _, ch := range children {
		status, err := s.GetChildLessonStatus(ch.ID)
		if err != nil {
			continue
		}
		out = append(out, *status)
	}
	return out, nil
}

// ---------- Groups ----------

func (s *Services) ListGroups() ([]domain.Group, error) {
	return s.Store.ListGroups()
}

func (s *Services) GetGroup(id int64) (*domain.Group, error) {
	return s.Store.GetGroup(id)
}

func (s *Services) CreateGroup(g domain.Group) (int64, error) {
	return s.Store.CreateGroup(g)
}

func (s *Services) UpdateGroup(g domain.Group) error {
	return s.Store.UpdateGroup(g)
}

func (s *Services) DeleteGroup(id int64) error {
	return s.Store.DeleteGroup(id)
}

func (s *Services) AddStudentToGroup(groupID, studentID int64, role string) error {
	if err := s.Store.AddStudentToGroup(groupID, studentID, role); err != nil {
		return err
	}
	c, _ := s.Store.StudentByID(studentID)
	if c != nil && c.CoachID == nil {
		g, _ := s.Store.GetGroup(groupID)
		if g != nil && g.CoachID != nil {
			_ = s.Store.SetStudentCoachID(studentID, *g.CoachID)
		}
	}
	return nil
}

func (s *Services) RemoveStudentFromGroup(groupID, studentID int64) error {
	return s.Store.RemoveStudentFromGroup(groupID, studentID)
}

func (s *Services) GetGroupStudents(groupID int64) ([]domain.GroupMember, error) {
	return s.Store.GetGroupStudents(groupID)
}

func (s *Services) GetStudentGroups(studentID int64) ([]domain.Group, error) {
	return s.Store.GetStudentGroups(studentID)
}

func (s *Services) StudentsNotInGroup(groupID int64) ([]domain.Student, error) {
	return s.Store.StudentsNotInGroup(groupID)
}

// ---------- Student Subscriptions ----------

func (s *Services) ClientSubscriptions(studentID int64) ([]domain.Subscription, error) {
	return s.Store.ClientSubscriptions(studentID)
}

func (s *Services) CreateClientSubscription(sub domain.Subscription) (int64, error) {
	return s.Store.CreateClientSubscription(sub)
}

func (s *Services) UpdateClientSubscription(sub domain.Subscription) error {
	return s.Store.UpdateClientSubscription(sub)
}

func (s *Services) DeleteClientSubscription(id int64) error {
	return s.Store.DeleteClientSubscription(id)
}

// ---------- Statistics ----------

type StatisticsRequest struct {
	Period   string
	CoachID  int64
	IsAdmin  bool
}

func (s *Services) GetStatistics(req StatisticsRequest) (*domain.StatisticsResponse, error) {
	now := time.Now()
	var from, to string
	var prevFrom, prevTo string

	switch req.Period {
	case "year":
		from = time.Date(now.Year(), 1, 1, 0, 0, 0, 0, now.Location()).Format("2006-01-02")
		to = now.Format("2006-01-02")
		prevFrom = time.Date(now.Year()-1, 1, 1, 0, 0, 0, 0, now.Location()).Format("2006-01-02")
		prevTo = time.Date(now.Year()-1, 12, 31, 0, 0, 0, 0, now.Location()).Format("2006-01-02")
	case "month":
		from = time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, now.Location()).Format("2006-01-02")
		to = now.Format("2006-01-02")
		prevFrom = time.Date(now.Year(), now.Month()-1, 1, 0, 0, 0, 0, now.Location()).Format("2006-01-02")
		prevTo = time.Date(now.Year(), now.Month(), 0, 0, 0, 0, 0, now.Location()).Format("2006-01-02")
	default: // week
		weekday := now.Weekday()
		if weekday == time.Sunday {
			weekday = 7
		}
		monday := now.AddDate(0, 0, -int(weekday-time.Monday))
		from = monday.Format("2006-01-02")
		to = now.Format("2006-01-02")
		prevFrom = monday.AddDate(0, 0, -7).Format("2006-01-02")
		prevTo = monday.AddDate(0, 0, -1).Format("2006-01-02")
	}

	resp := &domain.StatisticsResponse{
		Period:   req.Period,
		DateFrom: from,
		DateTo:   to,
	}

	var err error

	// Trainings
	curr, err := s.Store.TrainingCount(from, to, req.CoachID)
	if err != nil {
		return nil, err
	}
	prev, err := s.Store.TrainingCount(prevFrom, prevTo, req.CoachID)
	if err != nil {
		return nil, err
	}
	resp.Trainings = domain.MetricValue{Value: float64(curr), Change: float64(curr - prev), Label: "Тренировки"}

	// Active clients
	active, err := s.Store.ActiveClientsCount()
	if err != nil {
		return nil, err
	}
	newClients, err := s.Store.NewClientsCount(from, to)
	if err != nil {
		return nil, err
	}
	prevNewClients, err := s.Store.NewClientsCount(prevFrom, prevTo)
	if err != nil {
		return nil, err
	}
	resp.Students = domain.MetricValue{Value: float64(active), Change: float64(newClients - prevNewClients), Label: "Клиенты"}

	// Income
	income, err := s.Store.SubscriptionIncome(from, to)
	if err != nil {
		return nil, err
	}
	prevIncome, err := s.Store.SubscriptionIncome(prevFrom, prevTo)
	if err != nil {
		return nil, err
	}
	incomeChange := 0.0
	if prevIncome > 0 {
		incomeChange = (income - prevIncome) / prevIncome * 100
	}
	resp.Income = domain.IncomeMetric{Value: income, Change: incomeChange, Label: "Доход"}

	// Attendance
	attRate, err := s.Store.AttendanceRate(from, to)
	if err != nil {
		return nil, err
	}
	prevAttRate, err := s.Store.AttendanceRate(prevFrom, prevTo)
	if err != nil {
		return nil, err
	}
	attChange := attRate - prevAttRate
	resp.Attendance = domain.MetricValue{Value: attRate, Change: attChange, Label: "Посещаемость"}

	// Debtors
	debtorRows, err := s.Store.DebtorClients()
	if err != nil {
		return nil, err
	}
	var totalDebt float64
	var items []domain.DebtorItem
	for _, d := range debtorRows {
		totalDebt += d.Debt
		phone := nullStringPtr(d.Phone)
		endsAt := nullStringPtr(d.EndsAt)
		items = append(items, domain.DebtorItem{
			StudentID: d.StudentID,
			FullName: d.FullName,
			Phone:    phone,
			Debt:     d.Debt,
			EndsAt:   endsAt,
		})
	}
	resp.Debtors = domain.DebtorsSummary{
		Count:     len(items),
		TotalDebt: totalDebt,
		Items:     items,
	}

	// Income chart
	chartPoints, err := s.Store.IncomeChartData(from, to)
	if err != nil {
		return nil, err
	}
	resp.IncomeChart = aggChartPoints(chartPoints, req.Period)

	// Quick overview
	overview := domain.QuickOverview{}
	overview.NewStudents = newClients

	overview.AverageCheck = 0.0
	if income > 0 && curr > 0 {
		overview.AverageCheck = income / float64(curr)
	}

	canceled, err := s.Store.CanceledCount(from, to, req.CoachID)
	if err != nil {
		return nil, err
	}
	overview.CanceledCount = canceled

	overview.AvgAttendance = attRate

	avgGroupSize, err := s.Store.AvgGroupSize()
	if err != nil {
		return nil, err
	}
	overview.AvgGroupSize = avgGroupSize

	busiestDay, err := s.Store.BusiestDay(from, to, req.CoachID)
	if err != nil {
		return nil, err
	}
	overview.BusiestDay = busiestDay

	popularTime, err := s.Store.PopularTime(from, to, req.CoachID)
	if err != nil {
		return nil, err
	}
	overview.PopularTime = popularTime

	resp.QuickOverview = overview

	return resp, nil
}

func aggChartPoints(points []domain.ChartPoint, period string) []domain.ChartPoint {
	if len(points) == 0 {
		return nil
	}
	switch period {
	case "year":
		grouped := make(map[string]float64)
		for _, p := range points {
			if len(p.Label) >= 7 {
				monthKey := p.Label[:7]
				grouped[monthKey] += p.Value
			} else {
				grouped[p.Label] += p.Value
			}
		}
		var result []domain.ChartPoint
		for _, p := range points {
			key := p.Label
			if len(key) >= 7 {
				key = key[:7]
			}
			if _, seen := grouped[key]; seen {
				result = append(result, domain.ChartPoint{Label: key, Value: grouped[key]})
				delete(grouped, key)
			}
		}
		return result
	case "month":
		grouped := make(map[string]float64)
		for _, p := range points {
			t, err := time.Parse("2006-01-02", p.Label)
			if err != nil {
				grouped[p.Label] += p.Value
				continue
			}
			_, isoWeek := t.ISOWeek()
			weekKey := fmt.Sprintf("Нед %d", isoWeek)
			grouped[weekKey] += p.Value
		}
		var result []domain.ChartPoint
		for _, p := range points {
			t, err := time.Parse("2006-01-02", p.Label)
			if err != nil {
				continue
			}
			_, isoWeek := t.ISOWeek()
			weekKey := fmt.Sprintf("Нед %d", isoWeek)
			if _, seen := grouped[weekKey]; seen {
				result = append(result, domain.ChartPoint{Label: weekKey, Value: grouped[weekKey]})
				delete(grouped, weekKey)
			}
		}
		return result
	default: // week - daily
		var result []domain.ChartPoint
		for _, p := range points {
			t, err := time.Parse("2006-01-02", p.Label)
			if err != nil {
				result = append(result, p)
				continue
			}
			weekdays := map[string]string{
				"Monday": "Пн", "Tuesday": "Вт", "Wednesday": "Ср",
				"Thursday": "Чт", "Friday": "Пт", "Saturday": "Сб", "Sunday": "Вс",
			}
			short := weekdays[t.Weekday().String()]
			result = append(result, domain.ChartPoint{Label: short, Value: p.Value})
		}
		return result
	}
}

func nullStringPtr(ns sql.NullString) *string {
	if ns.Valid {
		return &ns.String
	}
	return nil
}
